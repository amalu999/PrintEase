<?php
require 'includes/sqlConnect.php';

if (!isset($_SESSION['prn_no'])) {
  header('location: index.php');
}

$session=$_SESSION['prn_no'];
if (isset($_POST['submit'])) {
	$file=$_FILES['file'];

	//print_r($file);
	$fileName=$_FILES['file']['name'];
	$fileTmpName=$_FILES['file']['tmp_name'];
	$fileSize=$_FILES['file']['size'];
	$fileError=$_FILES['file']['error'];
	//$fileType=$_FILES['file']['type'];
	
	$fileExt=explode('.', $fileName);
	$fileActualExt=strtolower(end($fileExt));
	



	$allow=array('jpg','jpeg','png','pdf','docx','txt','odt');
	

	$select_id_dupCheckprn="SELECT `id` `name` from `printease`.`files_tables` WHERE `name`='$filename'";
$resultprn= mysqli_query($connect, $select_id_dupCheckprn);
$prnQuery= @mysqli_num_rows($resultprn);
if($prnQuery>0) 
    {
 
   echo "<script language='javascript'>alert('file already exists:-) ')</script>";
    
   @die($mysqli_query);
 header('location:postLoginPage.php');
    }


	if(in_array($fileActualExt, $allow)){

		if($fileError===0){
			if($fileSize < 10000000){
				//$fileNameNew=uniqid('',true).".".$fileActualExt;
                 //$filedestination='upload/'.$file['name'];

				$filedestination="upload/$fileName";

              $success= move_uploaded_file($fileTmpName,$filedestination);

              header("Location:postLoginPage.php?uploadsuccess ");
              
               $session=$_SESSION['prn_no'];

              if($success === true){
                  // $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
               $query="INSERT INTO `printease`.`files_tables`(`prn_no`,`name`,`tmp_name`,`size`)VALUES('$session','$fileName','$filedestination','$fileSize')";
               mysqli_insert_id($connect);

               if(mysqli_query($connect,$query)){
               echo '<script>alert("file Successfully inserted:-)")</script>';
                header('location:postLoginPage.php?uploadSuccess');

                 }

               }
			}else{
				
				echo "<script language='javascript'>alert('Your file is too big!')</script>";
			
			}

		}else{
			echo "<script language='javascript'>alert('There was an error uploading your file! ')</script>";
			
		}

	}else{
		echo "<script language='javascript'>alert('enter the file!!! with proper extention:-) ')</script>";

	}

}

?>

<html>
    <head>
          <title>PrintEase | Welcome</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- fa fa image -->
    <link rel="stylesheet" href="style.css" type="text/css">
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#file').val();  
           if(image_name == '')  
           {  
                alert("Please Select a file");  
                return false;  
           }  
           else  
           {  
                var extension = $('#file').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg','docx','txt','odt','pdf']) == -1)  
                {  
                     alert('Invalid File type');  
                     $('#file').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>
 
 <style>
     body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 18px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

 </style>

    </head>
    <body class="container-fluid  relative" >
        <div id="main">
             <?php
        require 'includes/header.php';
        
        ?>
     
            <div class="container" style="padding-top: 60px">
            <div class="row row_style">
                <div class="relative">
                    <div class="panel panel-default" style="border: black solid medium">
                        <div class="panel-heading">
                                               
   <div id="mySidenav" class="sidenav" style="padding-top: 50px" >
  <a href="javascrip" class="closebtn" onclick="closeNav()">&times;</a>
  <?php
                            $prnno=$_SESSION['prn_no'];
                            $query="select * from printease.users_register where prn_no=$prnno";   //select query to display emailid
                            $query_result= mysqli_query($connect, $query);
                             while ($row1 = mysqli_fetch_array($query_result)) {
                            
                            ?>

	
 <a href="profile.php"><i class="fa fa-fw fa-home"></i>your Details</a>
 <hr>                        
<a href="#home"><i class="fa fa-fw fa-home"></i> Home</a>
<hr>
  <a href="recharge.php"><i class="fa fa-fw fa-money"></i> Recharge</a>
  <hr>
  <a href="#clients"><i class="fa fa-fw fa-user"></i> Home</a>
  <hr>
  <a href="#contact"><i class="fa fa-fw fa-envelope"></i>Home</a>
  <hr>
</div>
                            
  <table>    
      <tr>
     <td> <span class="responsive"  style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776;Welcome : <?php echo $row1['emailid']; ?> </span></td>
     <td style="padding-left:550px">Balance:</td>
<tr>
                            </table>                        
                               
      <?php
                           
          }
      ?>
    
                        
                           
 <!-- script for side menu -->
                            <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
 <!-- image insertion database is yet to be connected --> 
 
             <div align="left">
            
            <div class="panel-body">
                <form   name="fileinsert" action="postLoginPage.php" method="post"  enctype="multipart/form-data">

                    
             <div class="form-group row-style">
                <label for="insert" >Insert</label>   
                <input class="border form-control" type="file" name="file" id="file">  
            </div>
                       
            <div class="form-group row-style">
                <label for="select">select</label>  
               
                 <select name="printer" id="printer" class="form-control" required>
                   <option value = "select" >---Select---</option>';
                   <option value = "1" >Printer 1</option>';
                   <option value = "2" >Printer 2</option>';
                   <option value = "3" >Printer 3</option>';
               </select>
                             
            </div>
            <div class="form-group">
            <input type="submit" name="submit" id="submit" value="Upload" class="btn btn-info" /> 
                        </div>
                </form>
        </div>
                 
        
                 
                 
       
    <!--     <div class="container col-xs-offset-right-4 relative">
            <div class="table-responsive">
                <h4 align="left">Insert your file</h4>  
                <form  name="fileinsert" action="postLoginPage.php" method="post"  enctype="multipart/form-data">  
                    <table class="col-xs-3 table-bordered table">
                         <tr>
                           <td><input type="file" name="file" id="file">  </td>
                           <td><input type="submit" name="submit" id="submit" value="Upload" class="btn btn-info" />  </td>
                        </tr> 
                     
                    </table>  
                                     
                </form>  
                 
            
                     </div>
                <br />  
                <br />  
               </div>  -->
                 
                 <div class="container col-xs-offset-right-4 relative">
            <div class="table-responsive">
            <table class="table table-hover table-striped table-bordered">
                <tbody >
                    <tr>
                        <th class="col-xs-3">File Name</th>
                           <th class="col-xs-1">Size</th>
                           <th class="col-xs-1">Download</th> 
                           <th class="col-xs-1">Delete</th>
                           <th class="col-xs-1">Details</th><!--for downlaod-->
                           
                           <?php
		           $query="SELECT * FROM `printease`.`files_tables` where `prn_no`='$session'";
		           $result=mysqli_query($connect,$query);
		           while($row=@mysqli_fetch_array($result)){
			   $path=$row['tmp_name'];
			?>
            
                    </tr>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['size']; ?></td>
                        <td><?php echo "<a href='download.php?dow=$path'>Download</a>" ?></td>
                        
                        <td><?php echo "<a href='delete.php?del=$path'>Delete</a>" ?></td>
                        
                        
                        
                        <td><a data-toggle="modal" data-target="#myModal">Details</a></td>
                   
                         <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Details of document</h4>
        </div>
          
          
          
          
          <!--     some error                  -->
          <?php
                     $doc= $row['name'];      
           $query8="SELECT * FROM `printease`.`files_tables` where `name`='  $doc '";
		           $result8=mysqli_query($connect,$query8);
		           while($row=@mysqli_fetch_array($result8)){
          ?>
        <div class="modal-body">
          <p><?php echo $row['name']; ?></p>
        </div>
           <div class="modal-body">
          <p><?php echo $row['timestamp']; ?></p>
        </div>
           <div class="modal-body">
          <p><?php echo $row['printer']; ?></p>
        </div>
              
          <?php
                           }
          ?>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
                          
      </div>
      
    </div>
  </div>
                          
                        
                       
                     
                    </tr>
                    <?php
		       }
                     ?>
                </tbody>
            </table>
        </div>
        </div>
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                        </div>
                        <!--<div class="panel-footer">Panel footer</div>-->
                    </div>
                </div>
            </div>
        </div>
        
        
       
            
        </div> 
        
        
    </body>
     <?php
        require 'includes/footer.php';
        ?>
</html>


