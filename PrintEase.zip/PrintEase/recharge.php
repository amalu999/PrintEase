<?php

require 'includes/sqlConnect.php';

if (!isset($_SESSION['prn_no'])) {
  header('location: index.php');
}
?>



  <html>
    <head>
          <title>PrintEase | Recharge</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css" type="text/css">
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  

  
 
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
    </head>
    <body class="container-fluid">
        
         <?php
        require 'includes/header.php';
        ?>
    
          <div class="form" style="padding-top:60px" >
        <div class="container col-lg-6 col-xs-offset-3">
            
            <div class="panel panel-default" style="border: black solid medium" >
                <div class="panel-heading"><h3>Select mode of payment</h3></div>
           
            <div class="panel-body">
                
                <form name="form">
                <div class="table" name="form1">
                    <input type="radio" name="form" value="online" Onclick="onlineForm()" >Online</input>
                    <input type="radio" name="form" value="manually" onclick="openForm()">Manually</input>
                    
                </div>
                </form>
              
                  

              
</div>
            </div>
        </div>
          </div>
                
                <!-- popup window for manually pay -->
             <div class="form-popup" id="myForm" style="padding-top:60px"  >
        <div class="container col-lg-6 col-xs-offset-3">
            
                       <div class="panel panel-default" style="border: black solid medium" >
                <div class="panel-heading"><h3>note</h3></div>
           
            <div class="panel-body">
                <form  name="myForm1" method="post" action="profile_edit_script.php" onsubmit="">
                    <p>
                        u need to pay cash amount to the authorized admin .and he will make the changes in database.
                    </p>  
           <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
          
            </div>
        </div>
   </div>
  </div>
                
             <!-- popup window for online pay -->    
                
                
                <div class="form-popup" id="myForm1" style="padding-top:60px"  >
        <div class="container col-lg-6 col-xs-offset-3">
            
                       <div class="panel panel-default" style="border: black solid medium" >
                <div class="panel-heading"><h3>Select Your Payment gateWay</h3></div>
           
            <div class="panel-body">
                <form  name="myForm1" method="post" action="profile_edit_script.php" onsubmit="">
                    <p>
                     
                    </p>  
           <button type="button" class="btn cancel" onclick="closeForm1()">Close</button>
          
            </div>
        </div>
   </div>
  </div>
    
        
  </form>
            
                
<script>
function openForm() {
   alert ("u need to pay cash amount to the authorized admin .and he will make the changes in database.");
    document.getElementById().style.display = "block";
}
//function closeForm() {
//    document.getElementById("myForm").style.display = "none";
//}


function onlineForm() {
    document.getElementById("myForm1").style.display = "block";
}

function closeForm1() {
    document.getElementById("myForm1").style.display = "none";
}
</script>

<br>
<br>
<br>
 <?php
        require 'includes/footer.php';
        ?>
                                
            
    
    </body>
</html>


