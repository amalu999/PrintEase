<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require 'includes/sqlConnect.php';

if(isset($_GET['dow'])){

	$path=$_GET['dow'];
	$res=mysqli_query("Select * from `printease`.`files_tables` where `tmp_name`='$path'");

	header('Content-Type:application/octet-stream');
	header('Content-Disposition:attachment; filename="'.basename($path).'"');
	header('Content-Length:'.filesize($path));
	readfile($path);

}
?>