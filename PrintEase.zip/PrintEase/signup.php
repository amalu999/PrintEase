<?php
require 'includes/sqlConnect.php';

if (isset($_SESSION['prn_no'])) {
  header('location: postLoginPage.php');
}

?>

<html>
    <head>
        <title>PrintEase | signup</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    
    <link rel="stylesheet" href="style.css" type="text/css">
    <script>
    function validateForm() {
        
    
    }
    </script>
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body class="container-fluid">
          <div class="form" style="padding-top:60px" >
        <div class="container col-lg-6 col-xs-offset-3">
            
            <div class="panel panel-default " style="border: black solid medium " >
                <div class="panel-heading"><h3>User Registration</h3></div>
           
            <div class="panel-body">
                <form  name="myForm" method="post" action="user_registration_script.php" onsubmit="return validateForm()">
            <div class="form-group row-style">
                <label for="emailid">Email</label> 
                <input type="email" class="form-control" id="emailid" name="emailid" placeholder="" required>    
            </div>
                    
             <div class="form-group row-style">
                <label for="prn_no" >PRN NO</label>   
                <input type="number" class="form-control" id="prn_no" name="prn_no" placeholder="" required>    
            </div>
                    
             <div class="form-group row-style">
                <label for="name" >Your Name</label>   
               <input type="text" class="form-control" id="name" name="name" placeholder="" required>    
            </div>
            
            <div class="form-group row-style">
                <label for="department" >Department</label>   
                
               <select name="department" id="department" class="form-control" required>
                   <option value = "select" >---Select---</option>';
                   <option value = "1" >COMP</option>';
                   <option value = "2" >EXTC</option>';
                   <option value = "3" >IT</option>';
               </select>
                                       
                  

            </div>
            
            <div class="form-group row-style">
                <label for="password">Password</label>  
               <input type="password" class="form-control"  id="password" name="password" placeholder="" required>    
            </div>
            <div class="form-group">
                              <button type="submit" class="btn btn-primary" style="padding:10px,50px,10px,50px;">Submit</button>
                        </div>
        </div>
                 </div>
        </div>
        </form>
            </div>
    
    </body>
</html>

