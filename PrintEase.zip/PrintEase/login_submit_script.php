<?php

require 'includes/sqlConnect.php';

$prn_no=$_POST['prn_no'];
$prn_no= mysqli_escape_string($connect ,$prn_no);
 $password=$_POST['password'];
 $password= mysqli_escape_string($connect,$password); 
// $emailid=$_REQUEST['emailid'];
// $emailid= mysqli_escape_string($connect, $emailid); 
 
 $password=md5($password);          //loginSide hash
 
 $query="SELECT `id`, `prn_no`,`emailid`  from printease.users_register WHERE `prn_no`=' $prn_no' AND `password`='$password'";
 //$query="SELECT `id`, `prn_no`,`emailid`  from printease.users_register WHERE `prn_no`='" . $prn_no. "' AND `password`='" . $password . "'";
  
 
 $result = @mysqli_query($connect, $query);
 $num = mysqli_num_rows($result);

 
 if($num == 0){
    
      echo "<script language='javascript'>alert('prn no OR passowrd doesnot match:-) ')</script>";
     
     header('location: login.php');
 }else{
     
 $row = mysqli_fetch_array($result);
 $_SESSION['prn_no'] = $prn_no;
 $_SESSION['emailid'] = $emailid;
 $_SESSION['id'] = $id;
  header('location:postLoginPage.php');
 }

?>