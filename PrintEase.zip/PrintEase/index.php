

<?php
require 'includes/sqlConnect.php';

if (isset($_SESSION['prn_no'])) {
  header('location: postLoginPage.php');
}

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>PrintEase</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <!-- Header -->
        <?php
        require 'includes/header.php';
        ?>
        
        
        
        
        <?php
        require 'includes/footer.php';
        ?>
    </body>
</html>
