<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html>
    <head>
        <title>E_Commerce website</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css" type="text/css">
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body class="container-fluid">
        <footer>
            <div class="container">
        <nav class="navbar navbar-inverse navbar-fixed-bottom foot">
            
            <p style="color: white"><center  >Copyright © PrintEase. All Rights Reserved and Contact Us: +91 90000 00000</center> </p>
            <li><a href = "aboutSystem.php"><span class = "glyphicon glyphicon-shopping-cart"></span> about us</a></li>
        </nav>
            </div>
        </footer>
       
    </body>
</html>

