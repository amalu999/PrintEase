<?php

$connect= mysqli_connect("localhost", "root", "", "printease") or die($connect);
@session_start();
?>