<?php

require 'includes/sqlConnect.php';

$emailid=$_POST['emailid'];
$emailid= mysqli_escape_string($connect, $emailid);
$regex_email = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";

$prn=$_POST['prn_no'];
$prn= mysqli_escape_string($connect, $prn);

$name=$_POST['name'];
$name= mysqli_escape_string($connect, $name);

$department=$_POST['department'];
$department= mysqli_escape_string($connect, $department);

$password=$_POST['password'];
$password= mysqli_escape_string($connect, $password);

 $password=md5($password);  //registrationSide hash;
 
 
if(!preg_match($regex_email,$emailid )){
    echo"Incorrect email";
}

$select_id_dupCheck="SELECT `id` `emailid` from  users_register WHERE $emailid=`emailid`";
$result= mysqli_query($connect, $select_id_dupCheck);
$num= @mysqli_num_rows($result);
if($num>0){
   echo "<script language='javascript'>alert(']email already exist :-) ')</script>";
    
     @die($mysqli_query);
     header('location:signup.php');
}



$select_id_dupCheckprn="SELECT `id` `prn_no` from users_register WHERE $prn=`prn_no`";
$resultprn= mysqli_query($connect, $select_id_dupCheckprn);
$prnQuery= @mysqli_num_rows($resultprn);
if($prnQuery>0) 
    {
 
   echo "<script language='javascript'>alert('PRN already exists:-) ')</script>";
    
   @die($mysqli_query);
 header('location:signup.php');
    }


$insert_query="INSERT INTO printease. users_register(emailid,prn_no,name,department,password)VALUES('$emailid','$prn','$name','$department','$password')";
mysqli_insert_id($connect);

    

$user_regitration_submit=mysqli_query($connect,$insert_query)
or die(mysqli_errno($connect));
echo "<script language='javascript'>alert('User Successfully inserted:-) ')</script>";


 
 $_SESSION['prn_no'] = $prn;
 $_SESSION['emailid'] = $emailid;
 $_SESSION['id'] = $id;
header('location:signup.php');
 
 




?>


