<?php
require 'includes/sqlConnect.php';

if (!isset($_SESSION['prn_no'])) {
  header('location: index.php');
}

$emailid=$_POST['emailid'];
$emailid= mysqli_escape_string($connect ,$emailid);
 $password=$_POST['password'];
 $password= mysqli_escape_string($connect,$password); 
 
 $prnno=$_SESSION['prn_no'];
 
 $query="UPDATE `printease`.`users_register` SET `emailid` = '$emailid',`password`='$password' WHERE `prn_no`= '$prnno'";
 echo $_SESSION['prn_no'];
 $query_result= mysqli_query($connect, $query);
 
 if ($query_result === true) {
     echo "<script language='javascript'>alert('successfully updated:-) ')</script>";
}else{
    echo "<script language='javascript'>alert('error in updateting record:-( ')</script>";
}

?>