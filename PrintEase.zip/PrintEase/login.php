<?php
require 'includes/sqlConnect.php';

if (isset($_SESSION['prn_no'])) {
  header('location: postLoginPage.php');
}

?>

  <html>
    <head>
          <title>PrintEase | loginPage</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css" type="text/css">
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body class="container-fluid">
          <div class="form" style="padding-top:60px" >
        <div class="container col-lg-6 col-xs-offset-3">
            
            <div class="panel panel-default" style="border: black solid medium" >
                <div class="panel-heading"><h3>Login</h3></div>
           
            <div class="panel-body">
                <form  name="myForm" method="post" action="login_submit_script.php" onsubmit="return validateForm()">

                    
             <div class="form-group row-style">
                <label for="prn_no" >PRN NO</label>   
                <input type="number" class="form-control" id="prn_no" name="prn_no" placeholder="" required>    
            </div>
                       
            <div class="form-group row-style">
                <label for="password">Password</label>  
               <input type="password" class="form-control"  id="password" name="password" placeholder="" required>    
            </div>
            <div class="form-group">
           <button type="submit" class="btn btn-primary" style="padding:10px,50px,10px,50px;">Submit</button>
           <b>Don't have a account Click<a href="signup.php"> here</a></b>
                        </div>
        </div>
                 </div>
        </div>
        </form>
            </div>
    
    </body>
</html>


