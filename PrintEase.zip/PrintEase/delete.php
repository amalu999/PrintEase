<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


require 'includes/sqlConnect.php';



if(isset($_GET['del'])){

	$path=$_GET['del'];
        
	$query="delete from `printease`.`files_tables` where `tmp_name`='$path'";
        
         $query_result= mysqli_query($connect, $query);

        
         
        if ($query_result === true) {
 
     echo "<script language='javascript'>alert('successfully deleted:-) ')</script>";
   
     
}else{
    echo "<script language='javascript'>alert('error in deleting record:-( ')</script>";
}
 
	

}
?>